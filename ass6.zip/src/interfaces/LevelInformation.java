package interfaces;
import geometry.Velocity;
import sprites.Block;
import geometry.Point;
import java.util.List;
/**.
 * Levelinformation interface
 */
// ID: 342677358
public interface LevelInformation {
    /**
     * @return int
     */
    int numberOfBalls();
    /**
     * @return list of velocity
     */
    // The initial velocity of each ball
    // Note that initialBallVelocities().size() == numberOfBalls()
    List<Velocity> initialBallVelocities();
    /**
     * @return int
     */
    int paddleSpeed();
    /**
     * @return int
     */
    int paddleWidth();
    /**
     * @return string
     */
    // the level name will be displayed at the top of the screen.
    String levelName();
    /**
     * @return sprite
     */
    // Returns a sprite with the background of the level
    Sprite getBackground();
    /**
     * @return list of blocks
     */
    // The Blocks that make up this level, each block contains
    // its size, color and location.
    List<Block> blocks();
    // Number of blocks that should be removed
    // before the level is considered to be "cleared".
    // This number should be <= blocks.size();
    /**
     * @return int
     */
    int numberOfBlocksToRemove();
    /**
     * @return point
     */
    Point paddlePoint();
}
