package interfaces;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import sprites.Ball;
// ID: 342677358
/**.
 * Interface collidable
 */
public interface Collidable {
    /**
     * @return  the "collision shape" of the object.
     */
    Rectangle getCollisionRectangle();
    /**
     * @param hitter ball
     * @param collisionPoint point
     * @param currentVelocity velocity
     * @return velocity hit
     */
    // Notify the object that we collided with it at collisionPoint with
    // a given velocity.
    // The return is the new velocity expected after the hit (based on
    // the force the object inflicted on us).
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}