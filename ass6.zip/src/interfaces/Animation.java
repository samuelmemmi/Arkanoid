package interfaces;
import biuoop.DrawSurface;
/**.
 * Animation interface
 */
// ID: 342677358
public interface Animation {
    /**
     * @param d drawsurface
     */
    void doOneFrame(DrawSurface d);
    /**
     * @return stop
     */
    boolean shouldStop();
}