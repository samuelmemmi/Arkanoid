package interfaces;
// ID: 342677358
import biuoop.DrawSurface;
/**.
 * Interface Sprite
 */
public interface Sprite {
    /**.
     * @param d surface
     */
    // draw the sprite to the screen
    void drawOn(DrawSurface d);
    /**.
     * notify the sprite that time has passed
     */
    void timePassed();
}