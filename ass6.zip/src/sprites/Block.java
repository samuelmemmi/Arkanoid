package sprites;
import gamesetting.GameLevel;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import hit.HitListener;
import hit.HitNotifier;
import biuoop.DrawSurface;
import interfaces.Collidable;
import interfaces.Sprite;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
// ID: 342677358
/**.
 * The class of the Block implements blocks in the game
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private Rectangle block;
    private Color color;
    private int hits;
    private List<HitListener> hitListeners;
    //Constructor
    /**
     * @param rectangle rectangle
     * @param color color
     */
    public Block(Rectangle rectangle, Color color) {
        this.block = rectangle;
        this.color = color;
        this.hitListeners = new ArrayList<HitListener>();
    }
    /**
     * @return this hits
     */
    public int getHits() {
        return this.hits;
    }
    /**
     * @param hits1 int
     */
    public void setHits(int hits1) {
        this.hits = hits1;
    }
    /**
     * @return the block
     */
    public Rectangle getCollisionRectangle() {
        return this.block;
    }
    /**
     * @return color
     */
    public Color getColor() {
        return this.color;
    }
    /**
     * @param hitter ball
     * @param collisionPoint point
     * @param currentVelocity velocity
     * @return the velocity hit
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        Rectangle block1 = getCollisionRectangle();
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();
        Velocity velocityHit = new Velocity(dx, dy); //give him the current velocity in case we did not change it
        //if the collision point is on horizontal line the velocity of the vertical direction should change
        if (block1.getHorizontal1().isOnLine(collisionPoint)
                || block1.getHorizontal2().isOnLine(collisionPoint)) {
            velocityHit = new Velocity(dx, -dy);
        }
        //if the collision point is on vertical line the velocity of the horizontal direction should change
        if (block1.getVertical1().isOnLine(collisionPoint)
                || block1.getVertical2().isOnLine(collisionPoint)) {
            velocityHit = new Velocity(-dx, dy);
        }
        setHits(1);
        this.notifyHit(hitter);
        return velocityHit;
    }
    /**
     * @param surface surface
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(getColor());
        surface.fillRectangle(getCollisionRectangle().getUpperLeft().getIntX(),
                getCollisionRectangle().getUpperLeft().getIntY(),
                (int) getCollisionRectangle().getWidth(), (int) getCollisionRectangle().getHeight());
        surface.setColor(Color.black);
        surface.drawRectangle(getCollisionRectangle().getUpperLeft().getIntX(),
                getCollisionRectangle().getUpperLeft().getIntY(),
                (int) getCollisionRectangle().getWidth(), (int) getCollisionRectangle().getHeight());
    }
    /**.
     * not use
     */
    public void timePassed() {

    }
    /**
     * @param g game
     */
    public void addToGame(GameLevel g) {
        //add sprite and collidable to the game
        g.addSprite(this);
        g.addCollidable(this);
    }
    /**
     * @param gameLevel game
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeCollidable(this);
        gameLevel.removeSprite(this);
    }
    /**
     * @param hl hitlistener
     */
    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }
    /**
     * @param hl hitlistener
     */
    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }
    /**
     * @param hitter ball
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}