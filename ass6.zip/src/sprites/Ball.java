package sprites;
import gamesetting.CollisionInfo;
import gamesetting.GameLevel;
import gamesetting.GameEnvironment;
import geometry.Line;
import geometry.Point;
import geometry.Velocity;
import biuoop.DrawSurface;
import interfaces.Collidable;
import interfaces.Sprite;
import java.awt.Color;
// ID: 342677358
/**.
 * Ball.
 * The Ball program implements an application that
 * create ball with velocity
 */
public class Ball implements Sprite {
    //fields
    private Point center;
    private double radius;
    private Color color;
    private Velocity velocity;
    private int width;
    private int height;
    private int xOfScreen;
    private int yOfScreen;
    private GameEnvironment gameEnvironment;
    private Line trajectoryOfBall;
    // constructor
    /**.
     * This is the constructor of the ball
     * give center , color and radius
     * @param p the center of circle
     * @param r   the radius
     * @param color the color
     *              return nothing
     */
    public Ball(Point p, double r, Color color) {
        this.center = p;
        this.radius = r;
        this.color = color;
    }
    /**.
     * This is the constructor of the ball
     * give x, y, color and radius
     * @param x of the circle
     * @param y of the circle
     * @param r   the radius
     * @param color the color
     *              return nothing
     */
    public Ball(int x, int y, int r, Color color) {
        this(new Point(x, y), r, color);
    }
    /**.
     * Give velocity to our velocity
     * @param v the velocity
     *              return nothing
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }
    /**.
     * Give speed to velocity
     * @param dx speed
     * @param dy speed
     *              return nothing
     */
    public void setVelocity(double dx, double dy) {
        this.setVelocity(new Velocity(dx, dy));
    }
    /**.
     * @return the velocity
     */
    public Velocity getVelocity() {
        return this.velocity;
    }
    /**
     * @param p the point
     * return nothing
     */
    public void setCenter(Point p) {
        this.center = p;
    }
    /**.
     * Give the borders of the screen
     * @param breadth the width of the border
     * @param rise the height of the border
     * @param x the x of the rectangle
     * @param y the y of the rectangle
     *              return nothing
     */
    public void setBorders(int breadth, int rise, int x, int y) {
        this.width = breadth;
        this.height = rise;
        this.xOfScreen = x;
        this.yOfScreen = y;
    }
    /**.
     * @return the int x of the circle
     */
    public int getX() {
        return this.center.getIntX();
    }
    /**.
     * @return the int y of the circle
     */
    public int getY() {
        return this.center.getIntY();
    }
    /**.
     * @return the int radius
     */
    public int getSize() {
        return (int) this.radius;
    }
    /**.
     * @return the color
     */
    public Color getColor() {
        return this.color;
    }
    /**
     * @return the center of the ball
     */
    public Point getCenter() {
        return this.center;
    }
    /**.
     * Draw the ball on the given DrawSurface
     * @param surface the surface
     * return nothing
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getColor());
        surface.fillCircle(this.getX(), this.getY(), this.getSize());
        surface.setColor(Color.black);
        surface.drawCircle(this.getX(), this.getY(), this.getSize());
    }
    /**
     * @param game the game environment
     */
    public void setGameEnvironment(GameEnvironment game) {
        this.gameEnvironment = game;
    }
    /**
     * @param trajectory trajectory of the line
     */
    public void setTrajectoryOfBall(Line trajectory) {
        this.trajectoryOfBall = trajectory;
    }
    /**
     * @return game environment
     */
    public GameEnvironment getGameEnvironment() {
        return this.gameEnvironment;
    }
    /**
     * @return TrajectoryOfBall
     */
    public Line getTrajectoryOfBall() {
        return this.trajectoryOfBall;
    }
    /**.
     * This is the function that move the ball step after step
     * return nothing
     */
    public void moveOneStep() {
        Point centerOfBall = getCenter();
        double x1 = centerOfBall.getX();
        double y1 = centerOfBall.getY();
        double x2 = x1 + getVelocity().getDx();
        double y2 = y1 + getVelocity().getDy();
        Line trajectory = new Line(x1, y1, x2, y2);
        //we create a line that is the trajectory of the ball
        setTrajectoryOfBall(trajectory);
        int corner1 = 0;
        int corner2 = 0;
        //to know if there is a collision with something
        CollisionInfo collisionInfo = gameEnvironment.getClosestCollision(trajectory);
        if (collisionInfo != null) {
            Point collision = collisionInfo.collisionPoint(); //the point of the collision
            //if the ball hit the left vertical of the block
            // we have to change the x of the center of the point
            if (collision.getX()
                    == collisionInfo.collisionObject().getCollisionRectangle().getVertical1().start().getX()) {
                Point p = new Point(collision.getX() - this.radius - 1, collision.getY());
                setCenter(p);
                corner1 = 1;
            }
            //if the ball hit the right vertical of the block
            // we have to change the x of the center of the point
            if (collision.getX()
                    == collisionInfo.collisionObject().getCollisionRectangle().getVertical2().start().getX()) {
                Point p = new Point(collision.getX() + this.radius + 1, collision.getY());
                setCenter(p);
                corner2 = 1;
            }
            //if the ball hit the up horizontal of the block
            // we have to change the y of the center of the point
            if (collision.getY()
                    == collisionInfo.collisionObject().getCollisionRectangle().getHorizontal1().start().getY()) {
                Point p = new Point(collision.getX(), collision.getY() - this.radius - 1);
                setCenter(p);
                if (corner1 == 1) { //if we hit the corner
                    Point p2 = new Point(collision.getX() - this.radius - 1, collision.getY());
                    setCenter(p2);
                }
            }
            //if the ball hit the down horizontal of the block
            // we have to change the y of the center of the point
            if (collision.getY()
                    == collisionInfo.collisionObject().getCollisionRectangle().getHorizontal2().start().getY()) {
                Point p = new Point(collision.getX(), collision.getY() + this.radius + 1);
                setCenter(p);
                if (corner2 == 1) { //if we hit the corner
                    Point p2 = new Point(collision.getX() + this.radius + 1, collision.getY());
                    setCenter(p2);
                }
            }
            //to know what kind of object this is
            //in order to change the velocity
            Collidable currentCollidable = collisionInfo.collisionObject();
            Velocity velocityHit = currentCollidable.hit(this, collision, getVelocity());
            setVelocity(velocityHit);
        } else {
            //if we hit the border we have to change the direction of the ball
            //the first is if we go out the screen on the side positive
            //and the second on the side negatif
            if (centerOfBall.getX() + getVelocity().getDx() + getSize() >= this.width
                    || centerOfBall.getX() + getVelocity().getDx() - getSize() <= this.xOfScreen) {
                Velocity v = new Velocity(getVelocity().getDx() * -1, getVelocity().getDy());
                setVelocity(v);
            }
            //if we hit the border on the top or on the bottom
            if (centerOfBall.getY() + getVelocity().getDy() + getSize() >= this.height
                    || centerOfBall.getY() + getVelocity().getDy() - getSize() <= this.yOfScreen) {
                Velocity v = new Velocity(getVelocity().getDx(), getVelocity().getDy() * -1);
                setVelocity(v);
            }
            setCenter(getVelocity().applyToPoint(getCenter()));
        }
    }
    /**.
     * takes care of the ball's next step
     */
    public void timePassed() {
        moveOneStep();
    }
    /**
     * @param g the game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
    /**
     * @param g the game
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
    }
}