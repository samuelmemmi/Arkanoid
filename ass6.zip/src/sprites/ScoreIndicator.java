package sprites;
// ID: 342677358
import biuoop.DrawSurface;
import gamesetting.Counter;
import gamesetting.GameLevel;
import interfaces.LevelInformation;
import interfaces.Sprite;
import java.awt.Color;
/**.
 * ScoreIndicator class
 */
public class ScoreIndicator implements Sprite {
    private Counter scoreIndicator;
    private LevelInformation level;
    /**
     * @param score counter
     * @param levelInformation levelinformation
     */
    public ScoreIndicator(Counter score, LevelInformation levelInformation) {
        this.scoreIndicator = score;
        this.level = levelInformation;
    }
    /**
     * .
     * @param d surface
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.GRAY);
        d.fillRectangle(0, 0, 800, 15);
        d.setColor(Color.white);
        d.drawText(300, 12, "Score: " + this.scoreIndicator.getValue(), 15);
        d.setColor(Color.white);
        d.drawText(520, 12, "Level Name: " + this.level.levelName(), 15);
    }
    /**
     * .
     * notify the sprite that time has passed
     */
    @Override
    public void timePassed() {

    }
    /**
     * @param g game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
