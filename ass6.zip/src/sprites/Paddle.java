package sprites;
import gamesetting.GameLevel;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Collidable;
import interfaces.Sprite;
import java.awt.Color;
// ID: 342677358
/**.
 * The paddle class implements a paddle that we are going to add to the game
 */
public class Paddle implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    private Rectangle paddle;
    private Color color;
    private double minBorders;
    private double maxBorders;
    /**
     * @param paddle paddle
     * @param color color
     */
    public Paddle(Rectangle paddle, Color color) {
        this.paddle = paddle;
        this.color = color;
    }
    /**
     * @param paddle1 paddle
     */
    public void setPaddle(Rectangle paddle1) {
        this.paddle = paddle1;
    }
    /**
     * @return color
     */
    public Color getColorOfPaddle() {
        return this.color;
    }
    /**
     * @param keyboard1 keyboard
     */
    public void setKeyboard(KeyboardSensor keyboard1) {
        this.keyboard = keyboard1;
    }
    /**
     * @return minBorders
     */
    public double getMinBorders() {
        return this.minBorders;
    }
    /**
     * @return maxBorders
     */
    public double getMaxBorders() {
        return this.maxBorders;
    }
    /**
     * @param min min
     * @param max max
     */
    public void setBorders(double min, double max) {
        this.minBorders = min;
        this.maxBorders = max;
    }
    /**
     * @return paddle
     */
    public Rectangle getCollisionRectangle() {
        return this.paddle;
    }
    /**.
     * we move the paddle to the left so we move the x in the left
     */
    public void moveLeft() {
        double x1 = getCollisionRectangle().getUpperLeft().getX();
        double y1 = getCollisionRectangle().getUpperLeft().getY();
        Point p1 = new Point(x1 - 5, y1);
        Rectangle paddle1 = new Rectangle(p1, getCollisionRectangle().getWidth(), getCollisionRectangle().getHeight());
        setPaddle(paddle1);
    }
    /**.
     * we move the paddle to the right so we move the x in the right
     */
    public void moveRight() {
        double x2 = getCollisionRectangle().getUpperLeft().getX();
        double y2 = getCollisionRectangle().getUpperLeft().getY();
        Point p2 = new Point(x2 + 5, y2);
        Rectangle paddle2 = new Rectangle(p2, getCollisionRectangle().getWidth(), getCollisionRectangle().getHeight());
        setPaddle(paddle2);
    }
    /**.
     * we move the paddle left or right with the left and right key of the computer
     */
    public void timePassed() {
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            if (getCollisionRectangle().getUpperLeft().getX() - 5 >= getMinBorders()) { //to not go out the screen
                moveLeft();
            }
        }
        if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            if (getCollisionRectangle().getUpperLeft().getX()
                    + getCollisionRectangle().getWidth() + 5 <= getMaxBorders()) {
                moveRight();
            }
        }
    }
    /**
     * @param d drawsurface
     */
    public void drawOn(DrawSurface d) {
        d.setColor(getColorOfPaddle());
        d.fillRectangle(getCollisionRectangle().getUpperLeft().getIntX(),
                getCollisionRectangle().getUpperLeft().getIntY(),
                (int) getCollisionRectangle().getWidth(), (int) getCollisionRectangle().getHeight());
        d.setColor(Color.black);
        d.drawRectangle(getCollisionRectangle().getUpperLeft().getIntX(),
                getCollisionRectangle().getUpperLeft().getIntY(),
                (int) getCollisionRectangle().getWidth(), (int) getCollisionRectangle().getHeight());
    }
    /**.
     * divide the paddle in 5 rectangle for the change of the velocity when we hit it
     * @return array of rectangle
     */
    public Rectangle[] divisionPaddle() {
        Rectangle[] divisionPaddle = new Rectangle[5];
        double x = getCollisionRectangle().getUpperLeft().getX();
        double y = getCollisionRectangle().getUpperLeft().getY();
        double widthDivision = getCollisionRectangle().getWidth() / 5;
        double height = getCollisionRectangle().getHeight();
        for (int i = 0; i < divisionPaddle.length; i++) {
            Point p = new Point(x + i * widthDivision, y);
            Rectangle rectangle = new Rectangle(p, widthDivision, height);
            divisionPaddle[i] = rectangle;
        }
        return divisionPaddle;
    }
    /**
     * @param hitter ball
     * @param collisionPoint point
     * @param currentVelocity velocity
     * @return velocity hit
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();
        Velocity velocityHit = new Velocity(dx, dy);
        Rectangle[] divisionPaddle = divisionPaddle();
        Point d1 = new Point(dx, dy); //to calculate the speed of the ball
        Point d2 = new Point(0, 0);
        if (divisionPaddle[0].getHorizontal1().isOnLine(collisionPoint)) { //we hit the first part of the paddle
            velocityHit = Velocity.fromAngleAndSpeed(150, d1.distance(d2)); //change the angle to 300
        }
        if (divisionPaddle[1].getHorizontal1().isOnLine(collisionPoint)) { //we hit the second part of the paddle
            velocityHit = Velocity.fromAngleAndSpeed(120, d1.distance(d2)); //change the angle to 330
        }
        if (divisionPaddle[2].getHorizontal1().isOnLine(collisionPoint)) { //we hit the middle of the paddle
            velocityHit = new Velocity(dx, -dy); //change the vertical
        }
        if (divisionPaddle[3].getHorizontal1().isOnLine(collisionPoint)) { //we hit the four part of the paddle
            velocityHit = Velocity.fromAngleAndSpeed(30, d1.distance(d2)); //change the angle to 30
        }
        if (divisionPaddle[4].getHorizontal1().isOnLine(collisionPoint)) { //we hit the five part of the paddle
            velocityHit = Velocity.fromAngleAndSpeed(60, d1.distance(d2)); //change the angle to 60
        }
        return velocityHit;
    }
    /**
     * @param g game
     */
    // Add this paddle to the game.
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }
}