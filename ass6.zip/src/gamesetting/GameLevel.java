package gamesetting;
import geometry.Point;
import geometry.Rectangle;
import interfaces.Animation;
import interfaces.Collidable;
import interfaces.LevelInformation;
import interfaces.Sprite;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import sprites.Ball;
import sprites.Block;
import sprites.Paddle;
import sprites.ScoreIndicator;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
// ID: 342677358
/**.
 * The game class implements the game with the paddle the block and the balls
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Paddle paddle1;
    private Counter blocksCounter;
    private Counter ballsCounter;
    private Counter scoreCounter;
    private Counter levelCounter;
    private AnimationRunner runner;
    private boolean running;
    private KeyboardSensor keyboardSensor;
    private LevelInformation levelInformation;
    /**.
     * Constructor
     * @param level levelinformation
     * @param score counter
     * @param gui1 gui
     * @param levelCount counter
     */
    public GameLevel(LevelInformation level, Counter score, GUI gui1, Counter levelCount) {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.gui = gui1;
        this.runner = new AnimationRunner(this.gui, 60);
        this.keyboardSensor = this.gui.getKeyboardSensor();
        this.levelInformation = level;
        this.scoreCounter = score;
        this.levelCounter = levelCount;
    }
    /**
     * @return sprites
     */
    public SpriteCollection getSprites() {
        return this.sprites;
    }
    /**
     * @return game environment
     */
    public GameEnvironment getEnvironment() {
        return this.environment;
    }
    /**
     * @param c collidable
     */
    public void addCollidable(Collidable c) {
        getEnvironment().addCollidable(c);
    }
    /**
     * @param s sprite
     */
    public void addSprite(Sprite s) {
        getSprites().addSprite(s);
    }
    /**
     * @param c collidable
     */
    public void removeCollidable(Collidable c) {
        getEnvironment().removeCollidable(c);
    }
    /**
     * @param s sprite
     */
    public void removeSprite(Sprite s) {
        getSprites().removeSprite(s);
    }
    /**
     * @return gui
     */
    public GUI getGui() {
        return this.gui;
    }
    /**
     * @param gui1 gui
     */
    public void setGui(GUI gui1) {
        this.gui = gui1;
    }
    /**.
     * create the balls for the game
     * @param level levelinformation
     */
    public void initializeBall(LevelInformation level) {
        for (int i = 0; i < level.numberOfBalls(); i++) {
            Ball ball1 = new Ball(new Point(390, 560), 5, Color.white);
            ball1.setVelocity(level.initialBallVelocities().get(i)); //give the ball velocity
            ball1.setGameEnvironment(getEnvironment()); //add to the environment
            ball1.setBorders(800, 600, 0, 0); //in order to not go out of the screen
            ball1.addToGame(this); //add to game
        }
    }
    /**.
     * create the blocks for the screen
     * @param level levelinformation
     */
    public void initializeBlocks(LevelInformation level) {
        addSprite(this.levelInformation.getBackground()); //add to sprite the background
        List<Block> blockList = new ArrayList<>();
        for (int i = 0; i < level.numberOfBlocksToRemove(); i++) {
            Block block = level.blocks().get(i);
            block.addToGame(this); //add them to the game
            blockList.add(block);
            block.setHits(1);
        }
        blockBorders(); //add the block of the borders
        this.blocksCounter = new Counter(blockList.size()); //the block counter
        BlockRemover blockRemover = new BlockRemover(this, this.blocksCounter);
        ScoreTrackingListener score = new ScoreTrackingListener(this.scoreCounter);
        ScoreIndicator scoreIndicator = new ScoreIndicator(this.scoreCounter, this.levelInformation);
        scoreIndicator.addToGame(this); //to add to game the score sprite
        for (Block block : blockList) { //add the block to the list of listener
            block.addHitListener(blockRemover);
            block.addHitListener(score);
        }
    }
    /**.
     * create the paddle for the game
     * @param level levelinformation
     */
    public void initializePaddle(LevelInformation level) {
        Point p = new Point(level.paddlePoint());
        Rectangle r = new Rectangle(p, level.paddleWidth(), 20);
        Paddle paddle = new Paddle(r, Color.ORANGE);
        this.paddle1 = paddle;
        paddle.setKeyboard(this.keyboardSensor);
        paddle.setBorders(10, 790); //in order that he not goes out the screen
        paddle.addToGame(this);
    }
    /**.
     * create block in the borders
     */
    public void blockBorders() {
        Rectangle rect1 = null;
        Block block1;
        Point p1 = null;
        for (int i = 0; i < 4; i++) { //create 4 block in different size in different place in the borders
            if (i == 0) {
                p1 = new Point(0, 0);
                rect1 = new Rectangle(p1, 800, 20);
                block1 = new Block(rect1, Color.white);
                block1.addToGame(this);
            }
            if (i == 1) {
                p1 = new Point(10, 580);
                rect1 = new Rectangle(p1, 780, 20);
                Block deathBlock = new Block(rect1, Color.white);
                this.ballsCounter = new Counter(this.levelInformation.numberOfBalls());
                BallRemover ballRemover = new BallRemover(this, this.ballsCounter);
                deathBlock.addHitListener(ballRemover);
                deathBlock.addToGame(this);
            }
            if (i == 2 || i == 3) { //two block in the side of the screen
                if (i == 2) {
                    p1 = new Point(0, 20);
                } else {
                    p1 = new Point(790, 20);
                }
                rect1 = new Rectangle(p1, 10, 580); //in the same size but different places
                block1 = new Block(rect1, Color.white);
                block1.addToGame(this);
            }
        }
    }
    /**
     * Initialize a new game: create the Blocks ,Sprites.Ball and Paddle
     * and add them to the game.
     */
    public void initialize() {
        initializeBlocks(this.levelInformation);
        initializePaddle(this.levelInformation);
        initializeBall(this.levelInformation);
    }
    /**.
     * Run the game -- start the animation loop
     */
    public void playOneTurn() {
        //countdown before turn starts.
        this.runner.run(new CountdownAnimation(2, new Counter(3), getSprites()));
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.runner.run(this);
    }
    /**
     * @param d drawsurface
     */
    @Override
    public void doOneFrame(DrawSurface d) {
        if (blocksCounter.getValue() == 0) { //if there is no more block add 100 points
            this.scoreCounter.increase(100);
            this.running = false;
            //if we are in the last level
            if (this.levelCounter.getValue() == 1) {
                this.runner.run(new KeyPressStoppableAnimation(this.keyboardSensor, KeyboardSensor.SPACE_KEY,
                        new YouWin(this.scoreCounter, this.gui)));
                this.gui.close();
            }
        }
        //if there are no more balls we loose the game
        if (ballsCounter.getValue() == 0) {
            this.running = false;
            this.runner.run(new KeyPressStoppableAnimation(this.keyboardSensor, KeyboardSensor.SPACE_KEY,
                    new GameOver(this.scoreCounter, this.gui)));
            this.gui.close();
        }
        if (this.keyboardSensor.isPressed("p")) {
            this.runner.run(new KeyPressStoppableAnimation(this.keyboardSensor, KeyboardSensor.SPACE_KEY,
                    new PauseScreen()));
        }
        getSprites().drawAllOn(d);
        getSprites().notifyAllTimePassed();
    }
    /**
     * @return the stop
     */
    @Override
    public boolean shouldStop() {
        return !this.running;
    }
    /**
     * @return counter ball
     */
    public Counter getBallsCounter() {
        return this.ballsCounter;
    }
}
