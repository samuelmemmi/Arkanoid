package gamesetting;
import geometry.Line;
import geometry.Point;
import geometry.Rectangle;
import interfaces.Collidable;
import java.util.ArrayList;
import java.util.List;
// ID: 342677358
/**.
 * The game environment class give us the information about the closest collidable colision
 */
public class GameEnvironment {
    private List<Collidable> collidables;
    /**
     * Implements a new Game environment.
     */
    public GameEnvironment() {
        this.collidables = new ArrayList<Collidable>();;
    }
    /**
     * add the given collidable to the environment.
     * @param c collidable
     */
    public void addCollidable(Collidable c) {
        this.collidables.add(c);
    }
    /**
     * @param c collidable
     */
    public void removeCollidable(Collidable c) {
        this.collidables.remove(c);
    }
    /**
     * @param trajectory line
     * @return collision info
     */
    // Assume an object moving from line.start() to line.end().
    // If this object will not collide with any of the collidables
    // in this collection, return null. Else, return the information
    // about the closest collision that is going to occur.
    public CollisionInfo getClosestCollision(Line trajectory) {
        Rectangle r;
        Point collision;
        //create a new list of Geometry.Point that is going to contain intersection points
        List<Point> points = new ArrayList<Point>();
        //list of double that is going to cointain the distance between the point colision
        //and the start of the trajectory line
        List<Double> distance = new ArrayList<Double>();
        //list of collidable that we are going to meet
        List<Collidable> rectangleCollidable = new ArrayList<Collidable>();
        for (Collidable c : collidables) {
            r = c.getCollisionRectangle();
            collision = trajectory.closestIntersectionToStartOfLine(r);
            if (collision != null) { //if there is collision
                points.add(collision);
                distance.add(collision.distance(trajectory.start()));
                rectangleCollidable.add(c);
            }
        }
        if (rectangleCollidable.size() == 0) { //we don't have collidable
            return null;
        }
        double minDistance = distance.get(0);
        int indexOfMin = 0;
        for (int j = 1; j < points.size(); j++) {
            if (distance.get(j) < minDistance) { //in order to know who is the closest collidable
                minDistance = distance.get(j);
                indexOfMin = j;
            }
        }
        return new CollisionInfo(rectangleCollidable.get(indexOfMin), points.get(indexOfMin));
    }
}
