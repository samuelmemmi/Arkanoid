package gamesetting;
import hit.HitListener;
import sprites.Ball;
import sprites.Block;
// ID: 342677358
/**.
 * BlockRemover is in charge of removing blocks from the game, as well as keeping count
 * of the number of blocks that remain.
 */
public class BlockRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBlocks;
    /**.
     * @param gameLevel1 game
     * @param removedBlocks counter
     */
    public BlockRemover(GameLevel gameLevel1, Counter removedBlocks) {
        this.gameLevel = gameLevel1;
        this.remainingBlocks = removedBlocks;
    }
    /**.
     * @param beingHit block
     * @param hitter ball
     */
    // Blocks that are hit should be removed
    // from the game. Remember to remove this listener from the block
    // that is being removed from the game.
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.setHits(beingHit.getHits() - 1);
        if (beingHit.getHits() == 0) {
            beingHit.removeFromGame(this.gameLevel);
            beingHit.removeHitListener(this);
            this.remainingBlocks.decrease(1);
        }
    }
}