package gamesetting;
import biuoop.DrawSurface;
import interfaces.Animation;
/**.
 * PauseScreen class
 */
// ID: 342677358
public class PauseScreen implements Animation {
    private boolean stop;
    /**.
     *PauseScreen constructor
     */
    public PauseScreen() {
        this.stop = false;
    }
    /**
     * @param d drawsurface
     */
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
    }
    /**
     * @return the stop
     */
    public boolean shouldStop() { return this.stop; }
}