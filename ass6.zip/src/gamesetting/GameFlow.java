package gamesetting;
import biuoop.GUI;
import interfaces.LevelInformation;
import java.util.ArrayList;
import java.util.List;
// ID: 342677358
/**.
 * Gameflow class
 */
public class GameFlow {
    private Counter scoreCounter;
    private GUI gui;
    /**
     * @param scoreCounter Counter
     * @param gui1 gui
     */
    public GameFlow(Counter scoreCounter, GUI gui1) {
        this.scoreCounter = scoreCounter;
        this.gui = gui1;
    }
    /**
     * @param levels list of levelinformation
     */
    public void runLevels(List<LevelInformation> levels) {
        List<LevelInformation> levelInformations = new ArrayList<>(levels); //copy the list we receive
        Counter levelCount = new Counter(levelInformations.size());
        for (LevelInformation levelInfo : levelInformations) {
            //create the gamelevel with the score and the level
            GameLevel level = new GameLevel(levelInfo, this.scoreCounter, this.gui, levelCount);
            level.initialize();
            level.playOneTurn();
            levelCount.decrease(1);
        }
    }
}

