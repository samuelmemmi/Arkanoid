package gamesetting;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import interfaces.Animation;
// ID: 342677358
/**.
 * AnimationRunner class
 */
public class AnimationRunner {
    private GUI gui;
    private int framesPerSecond;
    /**
     * @param gui1 gui
     * @param second int
     */
    public AnimationRunner(GUI gui1, int second) {
        this.gui = gui1;
        this.framesPerSecond = second;
    }
    /**
     * @param animation Animation
     */
    public void run(Animation animation) {
        Sleeper sleeper = new Sleeper();
        int millisecondsPerFrame = 1000 / this.framesPerSecond;
        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = this.gui.getDrawSurface();
            animation.doOneFrame(d);
            this.gui.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}