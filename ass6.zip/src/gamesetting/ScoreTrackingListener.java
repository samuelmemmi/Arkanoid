package gamesetting;
import hit.HitListener;
import sprites.Ball;
import sprites.Block;
/**.
 * ScoreTrackingListener class
 */
// ID: 342677358
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;
    /**
     * @param scoreCounter counter
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }
    /**
     * @param beingHit block
     * @param hitter ball
     */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        this.currentScore.increase(5);
    }
}
