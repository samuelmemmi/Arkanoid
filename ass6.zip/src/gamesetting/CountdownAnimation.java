package gamesetting;
import biuoop.DrawSurface;
import interfaces.Animation;
import java.awt.Color;
import static java.lang.System.currentTimeMillis;
// ID: 342677358
/**
 * The CountdownAnimation will display the given gameScreen
 * for numOfSeconds seconds, and on top of them it will show
 * a countdown from countFrom back to 1, where each number will
 * appear on the screen for (numOfSeconds / countFrom) seconds, before
 * it is replaced with the next one.
 */
public class CountdownAnimation implements Animation {
    private double numSec;
    private Counter count;
    private SpriteCollection gameScreen;
    private long currentTime;
    /**
     * @param numOfSeconds double
     * @param countFrom counter
     * @param gameScreen spritecollection
     */
    public CountdownAnimation(double numOfSeconds,
                              Counter countFrom,
                              SpriteCollection gameScreen) {
        this.count = countFrom;
        this.gameScreen = gameScreen;
        this.currentTime = currentTimeMillis();
        this.numSec = numOfSeconds;
    }
    /**
     * @param d drawsurface
     */
    public void doOneFrame(DrawSurface d) {
        if ((currentTimeMillis() - this.currentTime) >= (1000 * this.numSec / this.count.getValue())) { //to give time
            this.count.decrease(1);
            this.currentTime = currentTimeMillis();
        }
        this.gameScreen.drawAllOn(d); //to show
        d.setColor(Color.red);
        d.drawText(390, 250, " " + this.count.getValue(), 40);
    }
    /**
     * @return the stop
     */
    public boolean shouldStop() {
        return this.count.getValue() <= 0;
    }
}