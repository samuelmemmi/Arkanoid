package gamesetting;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;
/**.
 * KeyPressStoppableAnimation class
 */
// ID: 342677358
public class KeyPressStoppableAnimation implements Animation {
    private KeyboardSensor keyboardSensor;
    private String key;
    private Animation animation;
    private boolean isAlreadyPressed;
    private boolean stop;
    /**
     * @param sensor keyboard
     * @param key1 string
     * @param animation1 animation
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key1, Animation animation1) {
        this.animation = animation1;
        this.key = key1;
        this.keyboardSensor = sensor;
        this.stop = false;
        this.isAlreadyPressed = true;
    }
    /**
     * @param d drawsurface
     */
    @Override
    public void doOneFrame(DrawSurface d) {
        this.animation.doOneFrame(d);
        if (this.keyboardSensor.isPressed(this.key)) {
            if (!this.isAlreadyPressed) {
                this.isAlreadyPressed = true;
                this.stop = true;
            }
        } else {
            this.isAlreadyPressed = false;
        }
    }
    /**
     * @return the stop
     */
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
