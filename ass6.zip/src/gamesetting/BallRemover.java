package gamesetting;
import hit.HitListener;
import sprites.Ball;
import sprites.Block;
// ID: 342677358
/**.
 * Ballremover Class
 */
public class BallRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter removeBallsCounts;
    /**.
     * @param gameLevel1 game
     * @param ballcounts counter
     */
    public BallRemover(GameLevel gameLevel1, Counter ballcounts) {
        this.gameLevel = gameLevel1;
        this.removeBallsCounts = ballcounts;
    }
    /**.
     * @param beingHit block
     * @param hitter ball
     */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
            hitter.removeFromGame(this.gameLevel); //to remove from the game
            this.removeBallsCounts.decrease(1); //to decrease the count
    }
}
