package gamesetting;
import biuoop.DrawSurface;
import interfaces.Sprite;
import java.util.ArrayList;
import java.util.List;
// ID: 342677358
/**.
 * The spritecollection class call the draw on and the timepassed method
 */
public class SpriteCollection {
    private List<Sprite> spriteList;
    /**.
     * Constructor
     */
    public SpriteCollection() {
        this.spriteList = new ArrayList<Sprite>();
    }
    /**
     * @param s sprite
     */
    public void addSprite(Sprite s) {
        this.spriteList.add(s);
    }
    /**
     * @param s sprite
     */
    public void removeSprite(Sprite s) {
        this.spriteList.remove(s);
    }
    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        List<Sprite> copySprite = new ArrayList<Sprite>(spriteList);
        for (Sprite sprite : copySprite) {
            sprite.timePassed();
        }
    }
    /**
     * @param d drawsurface
     */
    // call drawOn(d) on all sprites.
    public void drawAllOn(DrawSurface d) {
        List<Sprite> copySprite = new ArrayList<Sprite>(spriteList);
        for (Sprite sprite : copySprite) {
            sprite.drawOn(d);
        }
    }
}
