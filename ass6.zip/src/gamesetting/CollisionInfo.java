package gamesetting;
import geometry.Point;
import interfaces.Collidable;
// ID: 342677358
/**.
 * The collision info class give us the information that we need about
 * the collision point and object
 */
public class CollisionInfo {
    private Point collision;
    private Collidable object;
    //Constructor
    /**.
     * @param object collidable
     * @param collision point
     */
    public CollisionInfo(Collidable object, Point collision) {
        this.object = object;
        this.collision = collision;
    }
    /**.
     * @return collision point
     */
    // the point at which the collision occurs.
    public Point collisionPoint() {
        return this.collision;
    }
    /**.
     * @return collidable object
     */
    // the collidable object involved in the collision.
    public Collidable collisionObject() {
        return this.object;
    }
}
