package gamesetting;
// ID: 342677358
/**.
 * Counter class
 */
public class Counter {
    private int count;
    /**.
     * @param p int
     */
    public Counter(int p) {
        this.count = p;
    }
    /**.
     * @param number int
     */
    // add number to current count.
    void increase(int number) {
        this.count += number;
    }
    /**.
     * @param number int
     */
    // subtract number from current count.
    void decrease(int number) {
        this.count -= number;
    }
    /**.
     * @return int count
     */
    // get current count.
    public int getValue() {
        return this.count;
    }
}