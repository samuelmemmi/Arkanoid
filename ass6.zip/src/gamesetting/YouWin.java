package gamesetting;
import biuoop.DrawSurface;
import biuoop.GUI;
import interfaces.Animation;
/**.
 * YouWin class
 */
// ID: 342677358
public class YouWin implements Animation {
    private boolean stop;
    private Counter scoreCount;
    private GUI gui;
    /**
     * @param count counter
     * @param gui1 gui
     */
    public YouWin(Counter count, GUI gui1) {
        this.stop = false;
        this.scoreCount = count;
        this.gui = gui1;
    }
    /**
     * @param d drawsurface
     */
    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "You Win! Your score is " + this.scoreCount.getValue(), 32);
    }
    /**
     * @return the stop
     */
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
