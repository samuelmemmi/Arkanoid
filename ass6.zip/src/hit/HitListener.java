package hit;
// ID: 342677358
import sprites.Ball;
import sprites.Block;
/**.
 * Interface Hitlistener
 */
public interface HitListener {
    /**
     * @param beingHit block
     * @param hitter ball
     */
    // This method is called whenever the beingHit object is hit.
    // The hitter parameter is the Sprites.Ball that's doing the hitting.
    void hitEvent(Block beingHit, Ball hitter);
}
