package geometry;
// ID: 342677358
import java.util.ArrayList;
import java.util.List;
/**
 * Geometry.Line.
 * The Geometry.Line program implements an application that
 * verify the distance of a line, if they intersect or not.
 */
public class Line {
    //class constants
    private static final double EPSILION = Math.pow(10, -4); //0.00001
    //Field
    private Point start;
    private Point end;
    private Double a, b;
    private boolean isVertical;
    // constructor
    /**
     * .
     * This function give an start to our start and end to our end
     *
     * @param start the first number
     * @param end   the second number
     *              return nothing
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
        this.calculateLine();
    }
    // constructor
    /**
     * .
     * This function give x and y to two points start and end
     *
     * @param x1 the x to the point start
     * @param y1 the y to the point end
     * @param x2 the x to the point end
     * @param y2 the y to the point end
     *           return nothing
     */
    public Line(double x1, double y1, double x2, double y2) {
        this(new Point(x1, y1), new Point(x2, y2));
    }
    /**.
     * This is the copy constructor
     * @param line
     *        a line
     * return nothing
     */
    public Line(Line line) {
        this(line.start.copy(), line.end.copy());
    }
    /**
     * .
     * This function return the distance of this point to the other point
     * @return a double number that is the distance
     */
    public double length() {

        return this.start.distance(this.end);
    }
    /**
     * .
     * This function return the middle point of a line
     * @return a point middle
     */
    public Point middle() {
        return this.start.middle(this.end);
    }
    /**
     * .
     * This function return the start value of this line
     * @return start
     */
    public Point start() {
        return new Point(this.start);
    }
    /**
     * .
     * This function return the end value of this line
     * @return end
     */
    public Point end() {
        return new Point(this.end);
    }
    /**.
     * This is the copy constructor
     * @return line
     */
    public Line copy() {
        return new Line(this);
    }
    /**.
     * This function calculate line by calling the slope and the constant
     * return nothing
     */
    private void calculateLine() {
        this.calcSlope();
        this.calcConstant();
    }
    /**.
     * This function calculate the slope of a line
     * return nothing
     */
    private void calcSlope() {
        if (Math.abs(this.start.getX() - this.end.getX()) <= EPSILION) { //if the two x points are the same
            this.isVertical = true; //we have a vertical line
            this.a = Double.NaN; //a is null
        } else {
            this.isVertical = false;
            this.a = (this.end.getY() - this.start.getY())
                    / (this.end.getX() - this.start.getX()); //calculate the slope
        }
    }
    /**.
     * This function calculate the constant of a line
     * return nothing
     */
    private void calcConstant() {
        if (this.isVertical) { //if this is vertical b is null
            this.b = Double.NaN;
        } else {
            this.b = (this.start.getY() - (this.a * this.start.getX()));
        }
    }
    /**
     * .
     * This function tell us if two numbers are equals
     * @param num1 the first number
     * @param num2   the second number
     * @return true or false
     */
    private static boolean doublesEqual(double num1, double num2) {

        return Math.abs(num1 - num2) <= EPSILION;
    }
    /**.
     * This function give us true if a point is on a line
     * @param point
     *        a point
     * @return true or false
     */
    public boolean isOnLine(Point point) {
        double length, otherLength;
        length = this.length();
        otherLength = this.start.distance(point) + point.distance(this.end);
        return doublesEqual(length, otherLength);
    }
    /**
     * .
     * This function return the point of the intersection or null if not intersecting
     * @param other an other line
     * @return point of the intersection
     */
    public Point intersectionWith(Line other) {
        double x = 0, y = 0;
        if (this.isVertical && other.isVertical) { //if two lines are vertical
            if (doublesEqual(this.start.getX(), other.start.getX())) { //if also the x of this point are equals
                if (other.isOnLine(this.start)) {  //we return one of the two points
                    return this.start.copy();
                } else {
                    return this.end.copy();
                }
            }
        } else if (this.isVertical) { // if one are vertical
            x = this.start.getX();
            y = other.a * x + other.b;
        } else if (other.isVertical) { // if the other is vertical
            x = other.start.getX();
            y = this.a * x + this.b;
        } else { //we have two not verticals lines
            x = (this.b - other.b) / (other.a - this.a);
            y = this.a * x + this.b;
        }
        Point intersection = new Point(x, y); //the intersection point and if he is on one line we have intersection
        if (!this.isOnLine(intersection) || !other.isOnLine(intersection)) {
            intersection = null;
        }
        return intersection;
    }
    /**
     * .
     * This function return true if the lines are intersecting
     * @param other an other line
     * @return boolean
     */
    public boolean isIntersecting(Line other) {
        return this.intersectionWith(other) != null;
    }
    /**
     * .
     * This function return true if this is the same line or false if not
     * @param other an other line
     * @return boolean
     */
    public boolean equals(Line other) {
        return start().equals(other.start()) && end().equals(other.end());
    }
    /**
     * @param rect rectangle
     * @return point closet
     */
    // If this line does not intersect with the rectangle, return null.
    // Otherwise, return the closest intersection point to the
    // start of the line.
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        List<Point> pointIntersectionList = new ArrayList<Point>();
        //we add all the point intersection that we have int he list
        pointIntersectionList.addAll(0, rect.intersectionPoints(this));
        int size = pointIntersectionList.size();
        double[] distance = new double[size];
        double minDistance;
        int indexOfMin = 0;
        if (size == 0) {
            return null;
        }
        for (int i = 0; i < size; i++) { //make all the distance between the start and the point in an array
            distance[i] = pointIntersectionList.get(i).distance(start());
        }
        minDistance = distance[0];
        for (int j = 1; j < size; j++) { //in order to know who is the closest point
            if (distance[j] < minDistance) {
                minDistance = distance[j];
                indexOfMin = j;
            }
        }
        return pointIntersectionList.get(indexOfMin);
    }
}