package geometry;
import java.util.ArrayList;
import java.util.List;
// ID: 342677358
/**.
 * The rectangle class create a rectangle
 */
public class Rectangle {
    private Point upperLeft;
    private double width;
    private double height;
    private Line horizontal1;
    private Line horizontal2;
    private Line vertical1;
    private Line vertical2;
    /**
     * @param upperLeft point upperleft of the rectangle
     * @param width the width of the rectangle
     * @param height the height of the rectangle
     */
    // Create a new rectangle with location and width/height.
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
        double upperX =  upperLeft.getX();
        double upperY = upperLeft.getY();
        //in order to create the rectangle
        this.horizontal1 = new Line(upperX, upperY, upperX + width, upperY);
        this.horizontal2 = new Line(upperX, upperY + height, upperX + width, upperY + height);
        this.vertical1 = new Line(upperX, upperY, upperX, upperY + height);
        this.vertical2 = new Line(upperX + width, upperY, upperX + width, upperY + height);
    }
    /**
     * @param line line
     * @return list of intersections points
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        List<Point> pointList = new ArrayList<Point>();
        //make a list of all the intersection point with the rectangle and a line
        if (this.horizontal1.intersectionWith(line) != null) {
            pointList.add(this.horizontal1.intersectionWith(line));
        }
        if (this.horizontal2.intersectionWith(line) != null) {
            pointList.add(this.horizontal2.intersectionWith(line));
        }
        if (this.vertical1.intersectionWith(line) != null) {
            pointList.add(this.vertical1.intersectionWith(line));
        }
        if (this.vertical2.intersectionWith(line) != null) {
            pointList.add(this.vertical2.intersectionWith(line));
        }
        return pointList;
    }
    /**
     * @return the width
     */
    public double getWidth() {
        return this.width;
    }
    /**
     * @return the height
     */
    public double getHeight() {
        return this.height;
    }
    /**
     * @return the upperleft point
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }
    /**
     * @return the horizontal line of the top
     */
    public Line getHorizontal1() {
        return this.horizontal1;
    }
    /**
     * @return the horizontal line of the bottom
     */
    public Line getHorizontal2() {
        return this.horizontal2;
    }
    /**
     * @return the vertical line of the left side
     */
    public Line getVertical1() {
        return this.vertical1;
    }
    /**
     * @return the vertical line of the right side
     */
    public Line getVertical2() {
        return this.vertical2;
    }
}
