package geometry; // ID: 342677358
/**
 * Point.
 * The Point program implements an application that
 * receive two numbers and make them a point.
 */
public class Point {
    //Fields
    private double x;
    private double y;
    // constructor
    /**.
     * This function give an x to our x and y to our y
     * @param x
     *        the first number
     * @param y
     *        the second number
     * return nothing
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
    /**.
     * This function give an x to the point x and y to the point y
     * @param point
     *        the first number
     * return nothing
     */
    public Point(Point point) {
        this.x = point.x;
        this.y = point.y;
    }
    /**.
     * This is the copy constructor
     * @return copy point
     */
    public Point copy() {
        return new Point(this);
    }
    /**.
     * This function return the distance of this point to the other point
     * @param other
     *        an other point
     * @return a double number that is the distance
     */
    public double distance(Point other) {
        return Math.sqrt(Math.pow((getX() - other.getX()), 2) + Math.pow((getY() - other.getY()), 2));
    }
    /**
     * .
     * This function return the middle point of a line
     * @param other
     *        an other point
     * @return a point middle
     */
    public Point middle(Point other) {
        return new Point((this.x + other.x) / 2, (this.y + other.y) / 2);
    }
    /**.
     * This function return true is the points are equal, false otherwise
     * @param other
     *        an other point
     * @return boolean
     */
    public boolean equals(Point other) {
        return getX() == other.getX() && getY() == other.getY();
    }
    /**.
     * This function return the x value of this point
     * @return x
     */
    public double getX() {
        return this.x;
    }
    /**.
     * This function return the y value of this point
     * @return y
     */
    public double getY() {
        return this.y;
    }
    /**.
     * This function return the x int value of this point
     * @return x
     */
    public int getIntX() {
        return (int) this.x;
    }
    /**.
     * This function return the y int value of this point
     * @return y
     */
    public int getIntY() {
        return (int) this.y;
    }
}
