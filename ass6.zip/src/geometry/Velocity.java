package geometry;
/**
 * Geometry.Velocity.
 * The Geometry.Velocity program implements an application that
 * give velocity to ball
 */
public class Velocity {
    // constructor
    private double dx;
    private double dy;
    // constructor
    /**.
     * This function give an dx to our dx and dy to our dy
     * @param dx
     *        the first number
     * @param dy
     *        the second number
     * return nothing
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**.
     * Take a point with position (x,y) and return a new point
     * with position (x+dx, y+dy)
     * @param p
     *        a point
     * @return new point
     */
    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }
    /**.
     * This is a method
     * that will create new instances for us, instead of the constructor
     * by giving new speed and angle
     * @param angle
     *        the angle
     * @param speed
     *        the speed
     * @return new velocity
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double newDx = speed * (Math.cos(Math.toRadians(angle)));
        double newDy = -speed * (Math.sin(Math.toRadians(angle)));
        return new Velocity(newDx, newDy);
    }
    /**.
     * This function return the dx value of the velocity
     * @return dx
     */
    public double getDx() {
        return this.dx;
    }
    /**.
     * This function return the dy value of the velocity
     * @return dy
     */
    public double getDy() {
        return this.dy;
    }
}
