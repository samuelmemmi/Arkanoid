// ID: 342677358
import biuoop.GUI;
import gamesetting.Counter;
import gamesetting.GameFlow;
import interfaces.LevelInformation;
import levels.DirectHit;
import levels.FinalFour;
import levels.Green3;
import levels.WideEasy;
import java.util.ArrayList;
import java.util.List;
/**
 * Ass6Game.
 */
public class Ass6Game {
    /**
     * @param args string
     * @return boolean
     */
    private static boolean isNumber(String args) {
        try {
            Integer.parseInt(args);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    /**
     * @param level int
     * @return level information
     */
    private static LevelInformation levelName(int level) {
        if (level == 1) {
            return new DirectHit();
        }
        if (level == 2) {
            return new WideEasy();
        }
        if (level == 3) {
            return new Green3();
        }
        if (level == 4) {
            return new FinalFour();
        }
        return null;
    }
    /**
     * @param levelInformations list of level
     */
    private static void levelInformationList(List<LevelInformation> levelInformations) {
        levelInformations.add(new DirectHit());
        levelInformations.add(new WideEasy());
        levelInformations.add(new Green3());
        levelInformations.add(new FinalFour());
    }
    /**
     * The game of the application.
     * @param args the input arguments
     */
    public static void main(String[] args) {
        List<LevelInformation> levelInformations = new ArrayList<>();
        GUI gui = new GUI("Arkanoid", 800, 600);
        if (args.length != 0) {
            for (int i = 0; i < args.length; i++) {
                if (isNumber(args[i])) {
                    int level = Integer.parseInt(args[i]);
                    if (level > 0 && level < 5) {
                        levelInformations.add(levelName(level));
                    }
                }
            }
            if (levelInformations.size() == 0) {
                levelInformationList(levelInformations);
            }
        } else {
            levelInformationList(levelInformations);
        }
        GameFlow gameFlow = new GameFlow(new Counter(0), gui);
        gameFlow.runLevels(levelInformations);
    }
}
