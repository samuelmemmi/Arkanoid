package levels;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;
import sprites.Block;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**.
 * Green3 class
 */
public class Green3 implements LevelInformation {
    /**
     * @return int
     */
    @Override
    public int numberOfBalls() {
        return 2;
    }
    /**
     * @return list of velocity
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        for (int i = 0; i < numberOfBalls(); i++) {
            Velocity v = Velocity.fromAngleAndSpeed(45 + 50 * i, 4);
            velocityList.add(v);
        }
        return velocityList;
    }
    /**
     * @return int
     */
    @Override
    public int paddleSpeed() {
        return 0;
    }
    /**
     * @return int
     */
    @Override
    public int paddleWidth() {
        return 80;
    }
    /**
     * @return string
     */
    @Override
    public String levelName() {
        return "Green3";
    }
    /**
     * @return sprite
     */
    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600), Color.GREEN);
    }
    /**
     * @return list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        for (int i = 0; i < 7; i++) { //for to make the six blocks
            for (int j = i; j < 12; j++) { //for to make the block to be in order to 12 at 7
                int x = 200 + j * 50;
                int y = 100 + i * 20;
                Point p = new Point(x, y);
                Rectangle rectangle = new Rectangle(p, 50, 20);
                if (i == 0) { //the first grey block to we are going to make 12 of this
                    blockList.add(new Block(rectangle, Color.darkGray));
                }
                if (i == 1) { //the second red block to we are going to make 11 of this
                    blockList.add(new Block(rectangle, Color.RED));
                }
                if (i == 2) { //the third yellow block to we are going to make 10 of this
                    blockList.add(new Block(rectangle, Color.YELLOW));
                }
                if (i == 3) { //the four blue block to we are going to make 9 of this
                    blockList.add(new Block(rectangle, Color.BLUE));
                }
                if (i == 4) { //the five pink block to we are going to make 8 of this
                    blockList.add(new Block(rectangle, Color.PINK));
                }
                if (i == 5) { //the six green block to we are going to make 7 of this
                    blockList.add(new Block(rectangle, Color.white));
                }
            }
        }
        return blockList;
    }
    /**
     * @return point
     */
    public Point paddlePoint() {
        return new Point(350, 560);
    }
    /**
     * @return int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return 57;
    }

}
