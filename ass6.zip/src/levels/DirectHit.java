package levels;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;
import sprites.Block;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**.
 * DirectHit class
 */
public class DirectHit implements LevelInformation {
    /**
     * @return int
     */
    @Override
    public int numberOfBalls() {
        return 1;
    }
    /**
     * @return list of velocity
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        for (int i = 0; i < numberOfBalls(); i++) {
            Velocity v = Velocity.fromAngleAndSpeed(91, 5);
            velocityList.add(v);
        }
        return velocityList;
    }
    /**
     * @return int
     */
    @Override
    public int paddleSpeed() {
        return 0;
    }
    /**
     * @return point
     */
    public Point paddlePoint() {
        return new Point(350, 560);
    }
    /**
     * @return int
     */
    @Override
    public int paddleWidth() {
        return 80;
    }
    /**
     * @return string
     */
    @Override
    public String levelName() {
        return "Direct Hit";
    }
    /**
     * @return sprite
     */
    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600), Color.BLACK);
    }
    /**
     * @return list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        for (int i = 0; i < numberOfBlocksToRemove(); i++) {
            blockList.add(new Block(new Rectangle(new Point(375, 100), 25, 25), Color.RED));
        }
        return blockList;
    }
    /**
     * @return int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return 1;
    }

}
