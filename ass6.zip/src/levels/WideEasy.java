package levels;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;
import sprites.Block;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**.
 * WideEasy class
 */
public class WideEasy implements LevelInformation {
    /**
     * @return int
     */
    @Override
    public int numberOfBalls() {
        return 10;
    }
    /**
     * @return list of velocity
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Velocity v = Velocity.fromAngleAndSpeed(45 + (9 * i), 4);
            velocityList.add(v);
        }
        for (int i = 0; i < 5; i++) {
            Velocity v = Velocity.fromAngleAndSpeed(90 + (9 * i), 4);
            velocityList.add(v);
        }
        return velocityList;
    }
    /**
     * @return int
     */
    @Override
    public int paddleSpeed() {
        return 0;
    }
    /**
     * @return point
     */
    public Point paddlePoint() {
        return new Point(90, 560);
    }
    /**
     * @return int
     */
    @Override
    public int paddleWidth() {
        return 600;
    }
    /**
     * @return string
     */
    @Override
    public String levelName() {
        return "WideEasy";
    }
    /**
     * @return sprite
     */
    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600), Color.WHITE);
    }
    /**
     * @return list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        for (int i = 0; i < numberOfBlocksToRemove(); i++) {
            int x = 10 + i * 52;
            Point p = new Point(x, 300);
            if (i == 0 || i == 1) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.RED));
            }
            if (i == 2 || i == 3) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.orange));
            }
            if (i == 4 || i == 5) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.yellow));
            }
            if (i == 6 || i == 7 || i == 8) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.green));
            }
            if (i == 9 || i == 10) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.blue));
            }
            if (i == 11 || i == 12) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.magenta));
            }
            if (i == 13 || i == 14) {
                blockList.add(new Block(new Rectangle(p, 52, 20), Color.GRAY));
            }
        }
        return blockList;
    }
    /**
     * @return int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return 15;
    }

}
