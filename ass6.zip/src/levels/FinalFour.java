package levels;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;
import sprites.Block;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**.
 * FinalFour class
 */
public class FinalFour implements LevelInformation {
    /**
     * @return int
     */
    @Override
    public int numberOfBalls() {
        return 3;
    }
    /**
     * @return list of velocity
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList;
        velocityList = new ArrayList<>();
        for (int i = 0; i < numberOfBalls(); i++) {
            Velocity v = Velocity.fromAngleAndSpeed(45 + 50 * i, 4);
            velocityList.add(v);
        }
        return velocityList;
    }
    /**
     * @return int
     */
    @Override
    public int paddleSpeed() {
        return 0;
    }
    /**
     * @return int
     */
    @Override
    public int paddleWidth() {
        return 80;
    }
    /**
     * @return string
     */
    @Override
    public String levelName() {
        return "Final Four";
    }
    /**
     * @return sprite
     */
    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600), Color.blue);
    }
    /**
     * @return list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 15; j++) {
                Point p = new Point(10 + j * 52, 100 + i * 20);
                Rectangle rectangle = new Rectangle(p, 52, 20);
                if (i == 0) { //the first grey block to we are going to make 12 of this
                    blockList.add(new Block(rectangle, Color.darkGray));
                }
                if (i == 1) { //the second red block to we are going to make 11 of this
                    blockList.add(new Block(rectangle, Color.RED));
                }
                if (i == 2) { //the third yellow block to we are going to make 10 of this
                    blockList.add(new Block(rectangle, Color.YELLOW));
                }
                if (i == 3) { //the four blue block to we are going to make 9 of this
                    blockList.add(new Block(rectangle, Color.GREEN));
                }
                if (i == 4) { //the five pink block to we are going to make 8 of this
                    blockList.add(new Block(rectangle, Color.PINK));
                }
                if (i == 5) { //the six green block to we are going to make 7 of this
                    blockList.add(new Block(rectangle, Color.white));
                }
            }
        }
        return blockList;
    }
    /**
     * @return int
     */
    @Override
    public int numberOfBlocksToRemove() {
        return 90;
    }
    /**
     * @return point
     */
    public Point paddlePoint() {
        return new Point(350, 560);
    }

}
